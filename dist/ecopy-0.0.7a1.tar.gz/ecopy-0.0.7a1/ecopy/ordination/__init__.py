from pca import pca
from correspondance import ca
from pcoa import pcoa
from distance import distance
from transform import transform
from mds import MDS
from hillsmith import hillsmith
