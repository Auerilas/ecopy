from wt_mean import wt_mean
from wt_var import wt_var
from wt_scale import wt_scale
